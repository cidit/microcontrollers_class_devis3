#pragma once

void initUltrason();
float getDistance();