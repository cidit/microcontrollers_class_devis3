#pragma once

void initBumpers();

bool detecterObstacle();