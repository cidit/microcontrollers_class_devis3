#pragma once

void initBuzzer();

void alumerBuzzer();

void eteindreBuzzer();