#pragma once
#include <Arduino.h>

void initDels();
void changerCouleur(uint8_t rouge, uint8_t vert, uint8_t bleu);